#ifndef PLAGCHECK_H
#define PLAGCHECK_H

float checkPlagiarism(const char *inputPath, const char *dbPath);

#endif
